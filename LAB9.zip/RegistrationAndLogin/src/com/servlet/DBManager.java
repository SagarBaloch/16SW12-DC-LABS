package com.servlet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBManager {
	static Connection conn=DBConnection.getConnection();
	static PreparedStatement pst=null;
	public static boolean login(String username, String password)
	{
		boolean status=false;
		try 
		{
			pst=conn.prepareStatement("select * from registeruser where username=? and password=?");
			pst.setString(1, username);
			pst.setString(2, password);
			ResultSet rst=pst.executeQuery();
			status=rst.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
}
