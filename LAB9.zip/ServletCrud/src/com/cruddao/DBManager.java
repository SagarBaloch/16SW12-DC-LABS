package com.cruddao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.User;
import com.util.DBConnection;

public class DBManager 
{
	static Connection conn=DBConnection.getConnection();
	static PreparedStatement pst=null;
	public static int insertUser(User user)
	{
		int result = 0;
		try
		{
			pst=conn.prepareStatement("INSERT INTO `USER` (`NAME`,email,address) VALUES(?,?,?)");
			pst.setString(1, user.getName());
			pst.setString(2, user.getEmail());
			pst.setString(3, user.getAddress());
			result=pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public static List<User> getAllUser()
	{
		List<User> list=new ArrayList<User>();
		try 
		{
		pst=conn.prepareStatement("Select * from `user`");
		ResultSet rst=pst.executeQuery();
		while(rst.next())
		{
			User user = new User();
			user.setId(rst.getInt("id"));
			user.setName(rst.getString("name"));
			user.setEmail(rst.getString("email"));
			user.setAddress(rst.getString("address"));
			list.add(user);
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	public static User getUser(int id)
	{
		User user = new User();
		try 
		{
		pst=conn.prepareStatement("Select * from user where id=?");
		pst.setInt(1, id);
		ResultSet rst = pst.executeQuery();
		while(rst.next())
		{
			user.setName(rst.getString("name"));
			user.setEmail(rst.getString("email"));
			user.setAddress(rst.getString("address"));
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return user;
	}
	public static int deleteUser(int id)
	{
		int result=0;
		try 
		{
		pst=conn.prepareStatement("DELETE FROM USER WHERE id=?");
		pst.setInt(1, id);
		result = pst.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

}
