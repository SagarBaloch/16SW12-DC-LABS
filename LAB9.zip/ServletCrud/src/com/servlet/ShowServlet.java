package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.User;
import com.cruddao.DBManager;

@WebServlet("/show")
public class ShowServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		List<User> list = DBManager.getAllUser();
		int counter=0;
		pw.write("<html><body><table border=1px style='border-collapse:collapse;'>");
		pw.write("<tr><th>S.NO</th><th>Name</th><th>Email</th><th>Address</th><th>Update</th><th>Delete</th></tr>");
		for(User user:list)
		{
			pw.write("<tr>");
			pw.write("<td>"+(++counter)+"</td>");
			pw.write("<td>"+user.getName()+"</td>");
			pw.write("<td>"+user.getEmail()+"</td>");
			pw.write("<td>"+user.getAddress()+"</td>");
			pw.write("<td><a href=#?id="+user.getId()+">View</a></td>");
			pw.write("<td><a href=view?id="+user.getId()+">Delete</a></td>");
			pw.write("</tr>");
		}
		pw.write("</table></body></html>");
		pw.write("<br>");
		pw.write("<a href='addUser.html'>Add User</a><br>");
		pw.write("<a href='show'>Show Users</a>");
	}

}
