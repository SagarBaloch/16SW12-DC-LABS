package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.User;
import com.cruddao.DBManager;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		User user = new User();
		user.setName(request.getParameter("name"));
		user.setEmail(request.getParameter("email"));
		user.setAddress(request.getParameter("address"));
		int result=DBManager.insertUser(user);
		if(result!=0)
		{
			pw.print("<h1>Record inserted Successfully</h1>");
			request.getRequestDispatcher("show").include(request, response);
		}
		else
		{
			pw.println("<b>Record Not Inserted</b>");
			request.getRequestDispatcher("addUser.html").include(request, response);
		}
		
		
	}

}
